MelonEngine.Mesh = class { //overwrite for different configs, this is configured for defaultprogram
    /**
     * @constructor
     * @param {WebGLRenderingContext} gl - context
     * @param {MelonEngine.Mesh.AttributeType[]} attribTypes   
     * @param {Float32Array} vertices - vertex positions
     * @param {Uint16Array} indices - vertex indices
     * @param {Float32Array} [normals] - vertex normals (optional)
     * @param {Float32Array} [colors] - vertex colors (optional)
     * @param {Float32Array} [uvs] - texcoords (optional)
     * @param {WebGLTexture} [texture] -texture (required if uvs are included);
     */
    constructor(gl, attribTypes, {arrays = null, mesh = null, indices = null, customTypeSizes = null}){
        this.vao = gl.createVertexArray();
        this.vbo = gl.createBuffer();
        this.ibo = null;

        //reorder types here (so they get bound to shader properly)

        if (mesh) { //if a mesh is provided we will disregard any other arrays and set up the VAO
            this.importMesh();
        } else if (arrays) {
            this.buildFromArrays(gl, arrays, attribTypes, indices);
        }else {
            throw new Error("arrays or a mesh required");
        }
    }
    buildFromArrays(gl, arrays, types, indices = null){ //pass array types in corresponding order to how their shaderComponents are ordered
        
        //get stride from array of attribute sizes
        strideElements = 0;
        for (const type of types) {
            strideElements += types.size;
        }
        const stride = strideElements * Float32Array.BYTES_PER_ELEMENT;

        //for each attribute in the order they appear, set up VAO and pack VBO
        //-----------------------------------------------------------------------------------------------
        const vertexCount = arrays[0].length / sizes[0];
        const buffer = new Float32Array(vertexCount * strideElements);
        
        let offset = 0;
        gl.bindVertexArray(this.vao);

        //for each attribute
        for (let i = 0; i < arrays.length; i++) {
            const size = sizes[i];
            
            //set up pointer in vao
            gl.vertexAttribPointer(i, size, gl.FLOAT, false, stride, offset * Float32Array.BYTES_PER_ELEMENT);
            gl.enableVertexAttribArray(i);
            
            //pack the vbo
            for (let j = 0; j < vertexCount; j++) {
                buffer.set(arrays[i].slice(j * size, (j + 1) * size), j * strideElements + offset);
            }
            offset += size; //shift indices for next attribute
        }

        //bind complete vbo data 
        gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo);
        gl.bufferData(gl.ARRAY_BUFFER, buffer, gl.STATIC_DRAW);

        //handle ibo
        if(indices) {
            this.ibo = gl.createBuffer();
            gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ibo);
            gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW);
            this.indexCount = indices.length;
        } else {
            this.ibo = null;
            this.indexCount = 0;
        }

        gl.bindVertexArray(null);
    }
    importMesh(gl){

    }
    bind(gl){ 
        gl.bindVertexArray(this.vao);
    }
    cleanup(gl) {
        //not implemented
    }

    static AttributeType = {
        POSITION: {order: 0, size: 3},
        NORMAL: {order: 1, size: 3},
        UV: {order: 2, size: 2},
        VCOLORRGB: {order: 3, size: 3},
        VCOLORRGBA: {order: 3, size: 4},
        TANGENT: {order: 4, size: 3},
        BITANGENT: {order: 5, size: 3},
        BONE_INDEX: {order: 6, size: 4},
        BONE_WEIGHT: {order: 7, size: 4},
        CUSTOM: {order: 9 }
    }

}