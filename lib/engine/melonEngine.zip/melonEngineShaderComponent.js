MelonEngine.ShaderComponent = class {
    constructor(type,vertexIO = "", vertexMain = "", fragIO = "", fragMain = ""){
        this.type = type;
        this.vertexIO = vertexIO;
        this.vertexMain = vertexMain;
        this.fragIO = fragIO;
        this.fragMain = fragMain;
    }
    static Type = {
        POSITION: {order: 0, size: 3},
        NORMAL: {order: 1, size: 3},
        UV: {order: 2, size: 2},
        VCOLORRGB: {order: 3, size: 3},
        VCOLORRGBA: {order: 3, size: 4},
        TANGENT: {order: 4, size: 3},
        BITANGENT: {order: 5, size: 3},
        BONE_INDEX: {order: 6, size: 4},
        BONE_WEIGHT: {order: 7, size: 4},
        CUSTOM: {order: 9 }
    }
}