const MelonEngine = {
    const : { mat3, mat4, vec3 } = glMatrix
}